# Integración Ángel → Panther

Esta versión conserva el proyecto fuente de Panther y añade recursos extraíbles de Angel.zip:
- Imagen de marca, pantalla de inicio e icono basados en IMG_2524.png.
- Nombre visible: ÁNGEL VENDE PARTRIA.
- Los tres efectos de sonido de Angel.zip.
- Los cuatro recursos package_0.bin … package_3.bin de Angel.zip.
- Los paquetes Holograma Rtx.3105, HOLO ARM AZUL.3105 y HOLO PJ FFTH.3105 incluidos en el target de Xcode.

Limitaciones:
- Angel.zip contiene una app iOS compilada, no el código fuente de Ángel. No se puede fusionar literalmente su ejecutable ni su Assets.car con el código fuente de Panther; se añadieron sus recursos extraíbles.
- La key `prueba-2026` no se ha incrustado ni convertido en acceso permanente. Panther valida las keys con el servicio configurado en `PantherAPIBaseURL`; esa key debe estar autorizada allí.
- Este ZIP contiene el proyecto fuente, no un IPA compilado o firmado. Hace falta compilarlo con Xcode y probarlo en el dispositivo.
