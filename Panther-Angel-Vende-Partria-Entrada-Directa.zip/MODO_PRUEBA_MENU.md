# Entrada directa al menú de parches

La app abre directamente `PatchProjectsView` y ya no muestra la pantalla de licencia al iniciar.

Esto solo cambia la navegación local de la interfaz. Las operaciones y descargas protegidas del servidor siguen sujetas a la autorización del backend; esta modificación no crea una licencia ni concede permisos de servidor.

No se ha compilado ni probado en un dispositivo iPhone en este entorno.
